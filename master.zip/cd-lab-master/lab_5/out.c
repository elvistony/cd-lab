#include <stdio.h>
 
#define max 10
 

 
int main(){
 
  char count;
 
  int sums= 1+ 2;  
 

 
  if(1>2){
 
    printf(True);
 
  }
 
  return 0;
 
}
 

 
