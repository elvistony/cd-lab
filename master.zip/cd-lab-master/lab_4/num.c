#include<stdio.h>

int main () {
    int n;
    n = scanf ("%d");
    printf ("The Double of your number is %d",n);
    return 0;
}
