# Compiler Design - Lab
#### Academic - Lab - Experiments
##### Using Lex and Yacc
<hr>

Programs using LEX : 
- Lab 1) Counting Vowels and Consonants
- Lab 2) Counting Lines and Characters
- Lab 3) Infix Calculator
- Lab 4) Capitalize Keywords
- Lab 5)

Programs using LEX and YACC: 
- Lab 6)
- Lab 7) 
- Lab 8) Infix Calculator
- Lab 9) Intermediate Code Generator
- ..coming up
